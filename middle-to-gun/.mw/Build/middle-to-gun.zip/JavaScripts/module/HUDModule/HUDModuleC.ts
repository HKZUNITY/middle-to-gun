﻿import { EventType } from "../../tools/EventType";
import GlobalData from "../../tools/GlobalData";
import Utils from "../../tools/Utils";
import CoinPanel from "../CoinModule/ui/CoinPanel";
import { HUDData, KillTipType } from "./HUDData";
import HUDModuleS from "./HUDModuleS";
import HUDPanel from "./ui/HUDPanel";

export default class HUDModuleC extends ModuleC<HUDModuleS, HUDData> {
    private hudPanel: HUDPanel = null;
    private get getHUDPanel(): HUDPanel {
        if (!this.hudPanel) {
            this.hudPanel = UIService.getUI(HUDPanel);
        }
        return this.hudPanel;
    }

    public onOpenShopAction: Action = new Action();
    public onOpenTeamAction: Action = new Action();
    public onOpenRankAction: Action = new Action();
    public onOpenActivityAction: Action = new Action();
    public onOpenTaskAction: Action = new Action();
    public onResetPosAction: Action = new Action();

    protected onStart(): void {
        // this.initModule();
        this.initUIPanel();
        this.initEventAction();
    }

    // private initModule(): void {

    // }

    private initUIPanel(): void {
        this.hudPanel = UIService.getUI(HUDPanel);
    }

    private initEventAction(): void {
        this.initSetAction();
        this.initSoundEvent();
        Event.addLocalListener(EventType.OnOffMainHUD, this.addOnOffHUDPannel.bind(this));
        let isOpen = true;
        InputUtil.onKeyDown(mw.Keys.NumPadFive, () => {
            isOpen = !isOpen;
            isOpen ? UIService.getUI(CoinPanel).show() : UIService.getUI(CoinPanel).hide();
            Event.dispatchToLocal(EventType.OnOffMainHUD, isOpen);
        });
    }

    private addOnOffHUDPannel(isOpen: boolean): void {
        isOpen ? this.getHUDPanel.show() : this.getHUDPanel.hide();
    }

    protected onEnterScene(sceneType: number): void {
        this.getHUDPanel.show();
        this.setPlayerIcon();
        this.initSetData();
        this.playBgm();
    }

    protected onUpdate(dt: number): void {
        this.updatedoubleKill(dt);
    }

    //#region 击杀提示
    public killTip(killerUserId: string, killerName: string, killedUserId: string, killedName: string): void {
        let killTipType: KillTipType = KillTipType.None;
        if (killerUserId == this.localPlayer.userId) {
            killTipType = KillTipType.Killer;
        } else if (killedUserId == this.localPlayer.userId) {
            killTipType = KillTipType.Killed;
        }
        this.getHUDPanel.killTip(killTipType, killerName, killedName);
        this.killTipsSound(killerUserId, killerName, killedUserId, killedName);
    }
    //#endregion

    //#region 连杀提示

    private doubleTime: number = 1;
    private doubleTimer: number = 0;
    private keys: string[] = [];
    private updatedoubleKill(dt: number): void {
        this.doubleTimer += dt;
        if (this.doubleTimer >= this.doubleTime) {
            this.doubleTimer = 0;
            this.keys.length = 0;
            this.killCountTime.forEach((value: number, key: string) => {
                if (value > 0) this.keys.push(key);
            });
            for (let i = 0; i < this.keys.length; ++i) {
                if (this.killCountTime.has(this.keys[i])) {
                    this.killCountTime.set(this.keys[i], this.killCountTime.get(this.keys[i]) - 1);
                }
            }
        }
    }

    private killCountTime: Map<string, number> = new Map<string, number>();
    private killCountMap: Map<string, number> = new Map<string, number>();
    private revengeUserIdMap: Set<string> = new Set<string>();
    private killTipsSound(killerUserId: string, killerName: string, killedUserId: string, killedName: string): void {
        let killTipType: KillTipType = KillTipType.None;
        if (killedUserId == this.localPlayer.userId) {
            killTipType = KillTipType.Killed;
            if (!this.revengeUserIdMap.has(killerUserId)) this.revengeUserIdMap.add(killerUserId);
            SoundService.playSound("294343", 1, GlobalData.soundVolume);
        } else if (killerUserId == this.localPlayer.userId && this.revengeUserIdMap.has(killedUserId)) {
            killTipType = KillTipType.revenge;
            this.revengeUserIdMap.delete(killedUserId);
            SoundService.playSound("294342", 1, GlobalData.soundVolume);
        }
        this.getHUDPanel.showKillTips2(killerName, killedName, killTipType);

        if (this.killCountMap.has(killedUserId)) this.killCountMap.delete(killedUserId);
        if (this.killCountTime.has(killerUserId)) {
            if (this.killCountTime.get(killerUserId) == 0) {
                if (this.killCountMap.has(killerUserId)) this.killCountMap.delete(killerUserId);
            }
        }
        let killCount: number = 0;
        if (this.killCountMap.has(killerUserId)) {
            killCount = this.killCountMap.get(killerUserId);
        }
        killCount++;
        this.killCountMap.set(killerUserId, killCount);
        this.killCountTime.set(killerUserId, 10);
        if (killCount <= 1) return;

        let soundId: string = "";
        let killCountTips: string = "";
        switch (killCount) {
            case 2:
                soundId = "65877";
                killCountTips = "双杀！势不可当！";
                break;
            case 3:
                soundId = "65874";
                killCountTips = "三连杀！勇冠三军！";
                break;
            case 4:
                soundId = "65873";
                killCountTips = "四连杀！无人能敌！";
                break;
            case 5:
                soundId = "65881";
                killCountTips = "五连杀！横扫千军！";
                break;
            case 6:
                soundId = "65871";
                killCountTips = "六连杀！接近神了！";
                break;
            case 7:
                soundId = "65879";
                killCountTips = "七连杀！超越神了！";
                break;
            default:
                soundId = "65879";
                killCountTips = Utils.numChangeToCN(killCount) + "连杀！超越神了！";
                break;
        }
        SoundService.playSound(soundId, 1, GlobalData.soundVolume);
        this.getHUDPanel.showKillTips1(killCountTips, killerName, killedName);
    }
    //#endregion

    //#region Player-ICON-HP-Rank
    private setPlayerIcon(): void {
        if (mw.SystemUtil.isPIE) return;
        mw.AccountService.fillAvatar(this.getHUDPanel.mIconmage);
    }

    public updateHpUI(hp: number, isUpdateBarMaxHp: boolean = false): void {
        if (hp < 0) hp = 0;
        if (isUpdateBarMaxHp) this.getHUDPanel.updateProgressBarMaxHp(hp);
        this.getHUDPanel.updateHpUI(hp);
        if (hp <= 0) this.getHUDPanel.startDeadCountDown();
        if (hp == GlobalData.maxHp) this.getHUDPanel.endDeadCountDown();
    }

    public updateRankUIText(rank: number): void {
        this.getHUDPanel.updateRankUIText(rank);
    }
    //#endregion

    //#region Set
    public onFireScaleAction: Action1<number> = new Action1<number>();
    public onControlScaleAction: Action1<number> = new Action1<number>();
    public onBgmVolumeAction: Action1<number> = new Action1<number>();
    public onSoundVolumeAction: Action1<number> = new Action1<number>();

    private currentFireScale: number = 0.05;
    private currentControlScale: number = 0.3;
    private currentBgmVolume: number = 1;
    private currentSoundVolume: number = 1;

    private initSetData(): void {
        this.currentFireScale = this.data.fireScale;
        this.currentControlScale = this.data.controlScale;
        this.currentBgmVolume = this.data.bgmVolume;
        this.currentSoundVolume = this.data.soundVolume;
        GlobalData.soundVolume = this.currentSoundVolume;
        this.getHUDPanel.initSetData(this.currentFireScale, this.currentControlScale, this.currentBgmVolume, this.currentSoundVolume);
    }

    private initSetAction(): void {
        this.onFireScaleAction.add((scale: number) => {
            this.currentFireScale = scale;
        });
        this.onControlScaleAction.add((scale: number) => {
            this.currentControlScale = scale;
        });
        this.onBgmVolumeAction.add((volume: number) => {
            this.currentBgmVolume = volume;
            SoundService.BGMVolumeScale = volume;
        });
        this.onSoundVolumeAction.add((volume: number) => {
            this.currentSoundVolume = volume;
            GlobalData.soundVolume = volume;
        });
    }

    public get getFireScale(): number {
        return this.currentFireScale;
    }

    public saveSetData(): void {
        if (this.data.fireScale == this.currentFireScale &&
            this.data.controlScale == this.currentControlScale &&
            this.data.bgmVolume == this.currentBgmVolume &&
            this.data.soundVolume == this.currentFireScale) return;
        this.server.net_saveSetData(this.currentFireScale, this.currentControlScale, this.currentBgmVolume, this.currentSoundVolume);
    }
    //#endregion

    //#region SoundService
    private playBgm(): void {
        SoundService.playBGM("146100", this.currentBgmVolume);
    }

    private initSoundEvent(): void {
        Event.addLocalListener("PlayButtonClick", (btnName: string) => {
            if (btnName == "reload" || btnName == "jump" || btnName == "aim" || btnName == "left_fire") return;
            this.playClickSound();
        });
    }

    private clickId: string = null;
    private playClickSound(): void {
        if (this.clickId) SoundService.stopSound(this.clickId);
        this.clickId = SoundService.playSound("200082", 1, GlobalData.soundVolume);
    }
    //#endregion
}