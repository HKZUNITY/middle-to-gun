﻿import RadarModuleC from "./RadarModuleC";

export default class RadarModuleS extends ModuleS<RadarModuleC, null> {
    protected onStart(): void {

    }
}